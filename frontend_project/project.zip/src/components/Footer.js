import React from 'react'

export default function Footer() {
    return (

        <footer className="footer mt-auto py-3 bg-light mt-auto">
            <div className="container">
                <span className="text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias voluptas, at ad minus, consequatur illum voluptatibus eligendi modi dolorum error obcaecati !</span>
            </div>
        </footer>

    )
}