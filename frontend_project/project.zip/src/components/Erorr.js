import React from 'react'

export default function Erorr(){
    return(
        <div className='container my-3'  >
        <h2>You have made a mistake. Try again.</h2>
        </div>
    )
}