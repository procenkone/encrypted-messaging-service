import React from 'react'
import { useHistory } from 'react-router'

export default function Main() {
    const history = useHistory()
    

    return (
        <div className='container'>
       
            <div className='container mt-3'>
                <button
                onClick={()=>history.push("/create")}
                className="btn btn-primary m-2 btn-lg"  aria-current="page" >create note</button>

                <button
                onClick={()=>history.push("/note")}
                className="btn btn-primary m-2 btn-lg"  aria-current="page" >search note</button>
            </div>
        </div>
    )
}